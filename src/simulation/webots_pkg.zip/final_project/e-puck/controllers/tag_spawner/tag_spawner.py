"""tag_spawner controller."""
from controller import Supervisor
import csv
import os
import math

class TagSpawner(Supervisor):
    def __init__(self):
        super().__init__()
        self.timestep = int(self.getBasicTimeStep())
    
    def clear_old_tags(self):
        """Remove all existing ArUco tags from the world"""
        root = self.getRoot()
        children_field = root.getField('children')
        
        count = children_field.getCount()
        removed_count = 0
        for i in range(count - 1, -1, -1):
            node = children_field.getMFNode(i)
            if node.getTypeName() == "Solid" and 'aruco_tag' in node.getField('name').getSFString():
                children_field.removeMF(i)
                removed_count += 1
        
        if removed_count > 0:
            print(f"🧹 Removed {removed_count} old ArUco tags")
        
    def read_tag_coordinates(self, csv_file):
            """Read tag coordinates and rotation from CSV file"""
            tags = []
            try:
                abs_csv_path = os.path.abspath(csv_file)
                print(f"📁 Reading CSV from: {abs_csv_path}")
                
                with open(abs_csv_path, 'r') as file:
                    # Check headers
                    first_line = file.readline()
                    file.seek(0)
                    
                    if '\t' in first_line:
                        reader = csv.DictReader(file, delimiter='\t')
                    elif ';' in first_line:
                        reader = csv.DictReader(file, delimiter=';')
                    else:
                        reader = csv.DictReader(file)
                    
                    print(f"🔍 DETECTED HEADERS: {reader.fieldnames}")
    
                    for row in reader:
                        # Clean whitespace from keys
                        clean_row = {k.strip(): v for k, v in row.items() if k is not None}
                        
                        try:
                            tag_id = int(clean_row['ID'])
                            tag_type = clean_row['Type']
                            x = float(clean_row['X'])
                            y = float(clean_row['Y'])
                            z = float(clean_row['Z'])
                            
                            # FIX 1: Override Z height if necessary
                            # If you want to force them lower despite the CSV saying 1.5:
                            # z = 0.10  # Hardcoded height (10cm from floor)
                            # OR read from CSV and subtract offset:
                           
                            # FIX 2: Correct Yaw Detection (Case Sensitive)
                            if 'Yaw_deg' in clean_row:    # <--- Added exact match
                                yaw_val = clean_row['Yaw_deg']
                            elif 'yaw_deg' in clean_row:
                                yaw_val = clean_row['yaw_deg']
                            elif 'Yaw' in clean_row:
                                yaw_val = clean_row['Yaw']
                            elif 'yaw' in clean_row:
                                yaw_val = clean_row['yaw']
                            else:
                                yaw_val = '0'
    
                            yaw = float(yaw_val) if yaw_val and yaw_val.strip() != '' else 0.0
                            
                            tags.append((tag_id, tag_type, x, y, z, yaw))
                            print(f"  ✓ Tag {tag_id}: Yaw: {yaw}° | Z-Height: {z}")
                            
                        except KeyError as e:
                            print(f"⚠️ Skipping row due to missing column: {e}")
                            continue
                        
            except Exception as e:
                print(f"❌ Error reading CSV file: {e}")
                tags = []
                
            return tags
    
    def spawn_tag(self, tag_id, tag_type, x, y, z, yaw_deg):
        """Spawn an ArUco tag as a STATIC Solid node"""
        
        root = self.getRoot()
        children_field = root.getField('children')
        
        # Use forward slashes for VRML path compatibility
        texture_path = f"D:/AMRITA/sem 1/final_project/e-puck/textures/aruco_{tag_id}.png"
        
        # Outer Rotation (Yaw): Controls which wall it faces (NSEW)
        yaw_rad = math.radians(yaw_deg)
        
        # VRML String Definition
        # We add an inner Transform to "Stand Up" the tag (Rotate 90 deg around X axis)
        # This makes it vertical (for walls) instead of flat (for floor)
        tag_string = f"""
        Solid {{
          translation {x} {y} {z}
          rotation 0 0 1 {yaw_rad}
          name "aruco_tag_{tag_id}"
          children [
            Transform {{
              rotation 1 0 0 1.5708 
              children [
                Shape {{
                  appearance Appearance {{
                    texture ImageTexture {{
                      url [ "{texture_path}" ]
                    }}
                  }}
                  geometry Box {{
                    size 0.20 0.20 0.01 
                  }}
                }}
              ]
            }}
          ]
          boundingObject Box {{
            size 0.20 0.20 0.01
          }}
        }}
        """
        # Note: I increased thickness to 0.01 so you can see it better
        
        children_field.importMFNodeFromString(-1, tag_string)

    def run(self):
        print("=" * 60)
        print("🏷️  TAG SPAWNER STARTED")
        print("=" * 60)
        
        self.clear_old_tags()
        
        # Use Raw String for path
        csv_file = r"D:\AMRITA\sem 1\final_project\e-puck\aruco_tags.csv"
        
        tags = self.read_tag_coordinates(csv_file)
        
        if tags:
            print(f"\n📦 Spawning {len(tags)} tags...")
            for tag_id, tag_type, x, y, z, yaw in tags:
                self.spawn_tag(tag_id, tag_type, x, y, z, yaw)
            print("✅ Tags spawned successfully")
        else:
            print("❌ No tags found in CSV!")
        
        print("=" * 60)
        
        while self.step(self.timestep) != -1:
            pass

if __name__ == "__main__":
    controller = TagSpawner()
    controller.run()