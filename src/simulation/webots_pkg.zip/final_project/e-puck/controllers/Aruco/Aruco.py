"""Aruco controller."""
from controller import Robot, Keyboard
import cv2
import numpy as np
import os

class ArucoController(Robot):
    def __init__(self):
        super().__init__()
        self.timestep = int(self.getBasicTimeStep())
        
        # ---------------- CAMERA ----------------
        self.camera = self.getDevice("camera")
        self.camera.enable(self.timestep)
        
        self.width = self.camera.getWidth()
        self.height = self.camera.getHeight()
        self.fov = self.camera.getFov()
        
        # Camera intrinsic matrix (Webots pinhole model)
        # Focal length calculation based on FOV and width
        self.focal_length = self.width / (2 * np.tan(self.fov / 2))
        
        self.camera_matrix = np.array([
            [self.focal_length, 0, self.width / 2],
            [0, self.focal_length, self.height / 2],
            [0, 0, 1]
        ], dtype=np.float32)
        
        self.dist_coeffs = np.zeros((5, 1))  # No distortion in Webots
        
        # ---------------- MOTORS ----------------
        self.left = self.getDevice("left wheel motor")
        self.right = self.getDevice("right wheel motor")
        
        self.left.setPosition(float('inf'))
        self.right.setPosition(float('inf'))
        self.left.setVelocity(0)
        self.right.setVelocity(0)
        
        # ---------------- KEYBOARD ----------------
        self.keyboard = Keyboard()
        self.keyboard.enable(self.timestep)
        
        # ---------------- ARUCO ----------------
        self.aruco = cv2.aruco
        self.dictionary = self.aruco.getPredefinedDictionary(self.aruco.DICT_4X4_50)
        self.parameters = self.aruco.DetectorParameters()
        
        self.MARKER_SIZE = 0.20  # meters (must match Box size in tag_spawner)
        
        print("\n" + "=" * 70)
        print("🚀 ARUCO LOCALIZATION CONTROLLER STARTED")
        print("=" * 70)
        print(f"📷 Camera: {self.width}x{self.height}, FOV: {self.fov:.2f}")
        print(f"📐 Focal length: {self.focal_length:.2f}")
        print(f"🎯 Marker size: {self.MARKER_SIZE}m")
        print("\n🎮 Keyboard controls: Hold W/S/A/D to move.")
        print("=" * 70 + "\n")
        
    def run(self):
        """Main control loop"""
        frame_count = 0
        
        while self.step(self.timestep) != -1:
            
            # ---- CAMERA IMAGE ----
            img = self.camera.getImage()
            if img is None:
                continue
                
            # Convert Webots image (BGRA) to OpenCV format (BGR)
            # The .copy() is crucial to make the array writable for OpenCV drawing functions
            frame = np.frombuffer(img, dtype=np.uint8).reshape((self.height, self.width, 4))
            frame = frame[:, :, :3].copy() 
            
            # ---- ARUCO DETECTION ----
            corners, ids, _ = self.aruco.detectMarkers(
                frame,
                self.dictionary,
                parameters=self.parameters
            )
            
            # Clear terminal periodically
            frame_count += 1
            if frame_count % 30 == 0:
                os.system('cls' if os.name == 'nt' else 'clear')
            
            if ids is not None:
                # Estimate pose for each marker
                # Note: estimatePoseSingleMarkers is deprecated in new OpenCV but widely used.
                # If using OpenCV > 4.7, you might need to use solvePnP per marker, 
                # but this function usually persists in the objdetect module or legacy headers.
                rvecs, tvecs, _ = self.aruco.estimatePoseSingleMarkers(
                    corners,
                    self.MARKER_SIZE,
                    self.camera_matrix,
                    self.dist_coeffs
                )
                
                self.aruco.drawDetectedMarkers(frame, corners)
                
                # Print header
                print("\n📡 DETECTED MARKERS (relative to camera):")
                print("   ID     X (m)     Y (m)     Z (m)     Distance (m)")
                print("   ---    ------    ------    ------    ------------")
                
                for i, marker_id in enumerate(ids.flatten()):
                    rvec = rvecs[i]
                    tvec = tvecs[i]
                    
                    # Extract translation coordinates
                    # tvec structure is usually [[x, y, z]]
                    x, y, z = tvec[0][0], tvec[0][1], tvec[0][2]
                    distance = np.linalg.norm([x, y, z])
                    
                    print(f"   {marker_id:3d}    {x:6.3f}    {y:6.3f}    {z:6.3f}    {distance:8.3f}")
                    
                    # Draw axes (XYZ) on the marker
                    cv2.drawFrameAxes(
                        frame,
                        self.camera_matrix,
                        self.dist_coeffs,
                        rvec,
                        tvec,
                        0.1 # Length of the axis lines
                    )
                    
                    # Add text label
                    corners_flat = corners[i][0].astype(int)
                    top_left = tuple(corners_flat[0])
                    cv2.putText(frame, f"ID:{marker_id} Dist:{distance:.2f}m", top_left, 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
                
            else:
                # Print status when no markers are seen
                if frame_count % 30 == 0:
                     print("\n🔍 Scanning for markers...")
            
            # ---- DISPLAY ----
            cv2.imshow("Webots ArUco Detection", frame)
            cv2.waitKey(1)
            
            # ---- KEYBOARD CONTROL ----
            key = self.keyboard.getKey()
            
            # Default to zero (stop) if no key is pressed
            lv = 0.0
            rv = 0.0
            
            if key == ord('W'):
                lv = rv = 6.0
            elif key == ord('S'):
                lv = rv = -6.0
            elif key == ord('A'):
                lv = -4.0
                rv = 4.0
            elif key == ord('D'):
                lv = 4.0
                rv = -4.0
            elif key == ord(' '): 
                lv = rv = 0.0
                
            self.left.setVelocity(lv)
            self.right.setVelocity(rv)

# ---------------- MAIN ----------------
if __name__ == "__main__":
    controller = ArucoController()
    try:
        controller.run()
    except KeyboardInterrupt:
        print("\n👋 Controller stopped by user")
    finally:
        cv2.destroyAllWindows()