from controller import Robot, Keyboard
import cv2
import numpy as np

robot = Robot()
timestep = int(robot.getBasicTimeStep())

# Camera
camera = robot.getDevice("camera")
camera.enable(timestep)

# Motors
left = robot.getDevice("left wheel motor")
right = robot.getDevice("right wheel motor")
left.setPosition(float('inf'))
right.setPosition(float('inf'))
left.setVelocity(0)
right.setVelocity(0)

# Keyboard
keyboard = Keyboard()
keyboard.enable(timestep)

# ArUco dictionary
aruco = cv2.aruco
dictionary = aruco.getPredefinedDictionary(aruco.DICT_4X4_50)
parameters = aruco.DetectorParameters()

print("Python ArUco controller started!")

while robot.step(timestep) != -1:

    # ------------ CAMERA ----------------
    img = camera.getImage()
    w = camera.getWidth()
    h = camera.getHeight()

    # Convert Webots image -> OpenCV BGR
    frame = np.frombuffer(img, dtype=np.uint8).reshape((h, w, 4))
    frame = frame[:, :, :3]   # drop alpha channel (BGRA -> BGR)

    # ArUco detection
    corners, ids, _ = aruco.detectMarkers(frame, dictionary, parameters=parameters)

    if ids is not None:
        print("Detected ArUco IDs:", ids.flatten())

    # ------------ KEYBOARD CONTROL ----------------
    key = keyboard.getKey()

    lv = rv = 0

    if key == ord('W'):
        lv = rv = 5
    elif key == ord('S'):
        lv = rv = -5
    elif key == ord('A'):
        lv = -3
        rv = 3
    elif key == ord('D'):
        lv = 3
        rv = -3
    else:
        lv = rv = 0

    left.setVelocity(lv)
    right.setVelocity(rv)
